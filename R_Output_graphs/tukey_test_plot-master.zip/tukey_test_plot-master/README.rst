tukey_test_plot
==================

Match tukey test results (letters or asteriks resulting from the HSD.test function) and set them 
to their corresponding bar in a barplot. It takes into account possible facets from ggplot2.

